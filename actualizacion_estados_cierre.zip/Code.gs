/**
 * Agroterra · Seguimiento de Negocios — conexión con Google Sheets (con usuarios)
 *
 * Pegar en: Planilla de Google → Extensiones → Apps Script.
 * La primera vez que alguien entra a la app se crea sola la pestaña "Usuarios".
 * Ahí se define quién puede entrar: usuario, clave, rol (admin / vendedor) y
 * nombre del vendedor (tal cual figura en los negocios).
 *  - vendedor: ve y carga solo sus negocios.
 *  - admin: ve y edita los negocios de todos.
 * Implementar → Aplicación web · Ejecutar como: Yo · Acceso: Cualquier usuario.
 */
const HOJA = 'Negocios';
const HOJA_USUARIOS = 'Usuarios';

const COLS = ['id','fecha','vendedor','cliente','unidad','tipoUnidad','condicionUnidad','nis',
  'boletoNumero','boletoFecha','precio','moneda','financiacion','origen','tradeInModelo','tradeInValor',
  'pagoContado','pagoCreditoBanco','pagoFinancPropia1er','pagoFinancPropiaResto','estado','notas',
  'condicionesItems','historial','updatedAt','fechaCierre'];
const NUM_COLS = ['precio','tradeInValor','pagoContado','pagoCreditoBanco','pagoFinancPropia1er','pagoFinancPropiaResto'];
const JSON_COLS = ['condicionesItems','historial'];

function doGet(e) {
  try {
    const p = (e && e.parameter) || {};
    const user = auth_(p.usuario, p.clave);
    if (!user) return out_({ok:false, error:'clave'});
    return out_({ok:true, user: pub_(user), deals: visible_(readAll_(), user)});
  } catch (err) { return out_({ok:false, error:String(err)}); }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const body = JSON.parse(e.postData.contents);
    const user = auth_(body.usuario, body.clave);
    if (!user) return out_({ok:false, error:'clave'});
    lock.waitLock(20000);
    applyChanges_(body.upserts || [], body.deletes || [], user);
    return out_({ok:true, user: pub_(user), deals: visible_(readAll_(), user)});
  } catch (err) {
    return out_({ok:false, error:String(err)});
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

function norm_(s) { return String(s === null || s === undefined ? '' : s).trim().toLowerCase(); }

function pub_(u) { return {usuario: u.usuario, rol: u.rol, vendedor: u.vendedor}; }

function usersSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(HOJA_USUARIOS);
  if (!sh) {
    sh = ss.insertSheet(HOJA_USUARIOS);
    sh.getRange(1, 1, 1, 4).setValues([['usuario', 'clave', 'rol', 'vendedor']])
      .setFontWeight('bold').setBackground('#B4C6E7');
    sh.getRange(2, 1, 6, 4).setValues([
      ['Ramiro', 'CAMBIAR-1', 'admin', 'Ramiro'],
      ['Moscoso', 'CAMBIAR-2', 'vendedor', 'Moscoso Juan Pablo'],
      ['Busso', 'CAMBIAR-3', 'vendedor', 'Busso Diego'],
      ['Almiron', 'CAMBIAR-4', 'vendedor', 'Almirón Franco'],
      ['Leon', 'CAMBIAR-5', 'vendedor', 'Leon Miguel'],
      ['Agroterra', 'CAMBIAR-6', 'vendedor', 'Agroterra']
    ]);
    sh.getRange(1, 1, sh.getMaxRows(), 4).setNumberFormat('@');
    sh.setFrozenRows(1);
  }
  return sh;
}

function auth_(usuario, clave) {
  if (!usuario || !clave) return null;
  const sh = usersSheet_();
  const last = sh.getLastRow();
  if (last < 2) return null;
  const rows = sh.getRange(2, 1, last - 1, 4).getValues();
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    if (norm_(r[0]) && norm_(r[0]) === norm_(usuario) && String(r[1]).trim() === String(clave).trim()) {
      const rol = norm_(r[2]) === 'admin' ? 'admin' : 'vendedor';
      return {usuario: String(r[0]).trim(), rol: rol, vendedor: String(r[3]).trim()};
    }
  }
  Utilities.sleep(800);
  return null;
}

function visible_(deals, user) {
  if (user.rol === 'admin') return deals;
  return deals.filter(function (d) { return norm_(d.vendedor) === norm_(user.vendedor); });
}

function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(HOJA);
  if (!sh) sh = ss.insertSheet(HOJA);
  const header = sh.getLastRow() === 0 ? [] : sh.getRange(1, 1, 1, COLS.length).getValues()[0];
  if (header.join('|') !== COLS.join('|')) { // planilla nueva o con columnas nuevas por agregar
    sh.getRange(1, 1, 1, COLS.length).setValues([COLS])
      .setFontWeight('bold').setBackground('#B4C6E7');
    sh.setFrozenRows(1);
    COLS.forEach(function (c, i) {
      if (NUM_COLS.indexOf(c) === -1) sh.getRange(1, i + 1, sh.getMaxRows(), 1).setNumberFormat('@');
    });
  }
  return sh;
}

function toRow_(d) {
  return COLS.map(function (c) {
    let v = d[c];
    if (v === undefined || v === null) v = (JSON_COLS.indexOf(c) >= 0) ? [] : '';
    if (JSON_COLS.indexOf(c) >= 0) return JSON.stringify(v);
    if (NUM_COLS.indexOf(c) >= 0) return (v === '' ? '' : Number(v));
    return String(v);
  });
}

function fromRow_(row) {
  const tz = Session.getScriptTimeZone();
  const d = {};
  COLS.forEach(function (c, i) {
    let v = row[i];
    if (v instanceof Date) v = (c === 'updatedAt') ? v.toISOString() : Utilities.formatDate(v, tz, 'yyyy-MM-dd');
    if (JSON_COLS.indexOf(c) >= 0) {
      try { v = v === '' ? [] : JSON.parse(v); } catch (e) { v = []; }
    } else if (NUM_COLS.indexOf(c) >= 0) {
      v = (v === '' || v === null) ? '' : (isNaN(Number(v)) ? '' : Number(v));
    } else {
      v = (v === null || v === undefined) ? '' : String(v);
    }
    d[c] = v;
  });
  return d;
}

function readAll_() {
  const sh = sheet_();
  const last = sh.getLastRow();
  if (last < 2) return [];
  const range = sh.getRange(2, 1, last - 1, COLS.length);
  const values = range.getValues();
  const deals = [];
  let dirty = false;
  values.forEach(function (row) {
    const hasData = row.some(function (v, i) { return i > 0 && v !== ''; });
    if (!row[0] && !hasData) return;
    if (!row[0]) { // fila cargada a mano en la planilla: le damos un id
      row[0] = 'd_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      row[COLS.length - 1] = new Date().toISOString();
      if (!row[COLS.indexOf('estado')]) row[COLS.indexOf('estado')] = 'en_analisis';
      dirty = true;
    }
    deals.push(fromRow_(row));
  });
  if (dirty) range.setValues(values);
  return deals;
}

function applyChanges_(upserts, deletes, user) {
  const sh = sheet_();
  const last = sh.getLastRow();
  const vendCol = COLS.indexOf('vendedor');
  const updCol = COLS.indexOf('updatedAt');
  const data = last >= 2 ? sh.getRange(2, 1, last - 1, COLS.length).getValues() : [];
  const ids = data.map(function (r) { return String(r[0]); });
  const isAdmin = user.rol === 'admin';
  const mine = function (row) { return isAdmin || norm_(row[vendCol]) === norm_(user.vendedor); };
  upserts.forEach(function (d) {
    if (!d || !d.id) return;
    if (!isAdmin) d.vendedor = user.vendedor; // un vendedor solo carga a su nombre
    const idx = ids.indexOf(String(d.id));
    const row = toRow_(d);
    if (idx >= 0) {
      if (!mine(data[idx])) return; // no es suyo
      const cur = data[idx][updCol];
      const curIso = (cur instanceof Date) ? cur.toISOString() : String(cur || '');
      if (curIso && String(d.updatedAt || '') < curIso) return; // la planilla tiene algo más nuevo
      sh.getRange(idx + 2, 1, 1, COLS.length).setValues([row]);
      data[idx] = row;
    } else {
      sh.getRange(sh.getLastRow() + 1, 1, 1, COLS.length).setValues([row]);
      ids.push(String(d.id));
      data.push(row);
    }
  });
  const rowsToDelete = [];
  deletes.forEach(function (id) {
    const idx = ids.indexOf(String(id));
    if (idx >= 0 && mine(data[idx])) rowsToDelete.push(idx + 2);
  });
  rowsToDelete.sort(function (a, b) { return b - a; }).forEach(function (r) { sh.deleteRow(r); });
}

/** Si alguien edita una celda a mano en la planilla, marcamos la fila como "más nueva". */
function onEdit(e) {
  try {
    const sh = e.range.getSheet();
    if (sh.getName() !== HOJA || e.range.getRow() < 2) return;
    const updCol = COLS.indexOf('updatedAt') + 1;
    if (e.range.getColumn() === updCol) return;
    sh.getRange(e.range.getRow(), updCol).setValue(new Date().toISOString());
  } catch (err) {}
}
